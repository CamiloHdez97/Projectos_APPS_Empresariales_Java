/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package modelo;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.naming.NamingException;

/**
 *
 * @author Camilo Hernandez
 */
@Named(value = "productosMBean")
@RequestScoped
public class productosMBean {

    /**
     * Creates a new instance of productosMBean
     */
    public productosMBean() throws NamingException, NamingException, NamingException, NamingException {
    }
    
    int id;
    String serialP;
    String categoriaP;
    String marcaP;
    String refP;
    int precio;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSerialP() {
        return serialP;
    }

    public void setSerialP(String serialP) {
        this.serialP = serialP;
    }

    public String getCategoriaP() {
        return categoriaP;
    }

    public void setCategoriaP(String categoriaP) {
        this.categoriaP = categoriaP;
    }

    public String getMarcaP() {
        return marcaP;
    }

    public void setMarcaP(String marcaP) {
        this.marcaP = marcaP;
    }

    public String getRefP() {
        return refP;
    }

    public void setRefP(String refP) {
        this.refP = refP;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }
    
    //Metodos de acceso
    public List<Producto> getTablaProductos() throws NamingException{
        ProductoJpaController ctrl = new ProductoJpaController();
        List<Producto> lst = ctrl.findProductoEntities();
        return lst;
    }
    
    public void agregarProducto() throws NamingException{
        ProductoJpaController ctrl = new ProductoJpaController();
        try {
            ctrl.create(new Producto(serialP, categoriaP, marcaP, refP, precio));
        } catch (Exception ex) {
            Logger.getLogger(productosMBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void editarProducto() throws NamingException{
        ProductoJpaController ctrl = new ProductoJpaController();
        try {
            ctrl.edit(new Producto(serialP, categoriaP, marcaP, refP, precio));
        } catch (Exception ex) {
            Logger.getLogger(productosMBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void eliminarProducto() throws NamingException{
        ProductoJpaController ctrl = new ProductoJpaController();
        try {
            ctrl.destroy(id);
        } catch (Exception ex) {
            Logger.getLogger(productosMBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
