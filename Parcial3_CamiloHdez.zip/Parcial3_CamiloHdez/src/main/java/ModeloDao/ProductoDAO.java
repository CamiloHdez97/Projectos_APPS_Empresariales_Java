
package ModeloDAO;

import Config.Conexion;
import Interface.CRUD;
import modelo.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO implements CRUD{
    Conexion cn=new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Producto p=new Producto();
    
    @Override
    public List listar() {
        ArrayList<Producto>list=new ArrayList<>();
        String sql="select * from producto";
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                Producto pro=new Producto();
                pro.setId(rs.getInt("id"));
                pro.setSerialP(rs.getString("serialP"));
                pro.setCategoriaP(rs.getString("categoriaP"));
                pro.setMarcaP(rs.getString("marcaP"));
                pro.setRefP(rs.getString("refP"));
                pro.setPrecio(rs.getInt("precio"));
                list.add(pro);
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public Producto list(int id) {
        String sql="select * from producto where id="+id;
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){                
                p.setId(rs.getInt("id"));
                p.setSerialP(rs.getString("serialP"));
                p.setCategoriaP(rs.getString("categoriaP"));
                p.setMarcaP(rs.getString("marcaP"));
                p.setRefP(rs.getString("refP"));
                p.setPrecio(rs.getInt("precio"));
                
            }
        } catch (Exception e) {
        }
        return p;
    }

    @Override
    public boolean add(Producto pro) {
       String sql="insert into producto(serialP, categoriaP, marcaP, refP, precio) values('"+pro.getSerialP()+"','"+pro.getCategoriaP()+"','"+pro.getMarcaP()+"','"+pro.getRefP()+"','"+pro.getPrecio()+"')";
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
       return false;
    }

    @Override
    public boolean edit(Producto pro) {
        String sql="update producto set serialP='"+pro.getSerialP()+"','"+pro.getCategoriaP()+"','"+pro.getMarcaP()+"','"+pro.getRefP()+"','"+pro.getPrecio()+pro.getId();
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int id) {
        String sql="delete from producto where id="+id;
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return false;
    }
    
}
