package Controlador;

import ModeloDAO.ProductoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Producto;

/**
 *
 * @author Camilo Hernandez
 */
public class Controlador extends HttpServlet {

    String listar="vista/ListaProducto.jsp";
    String add="vista/agregarProducto.jsp";
    String edit="vista/editarProducto.jsp";
    Producto p=new Producto();
    ProductoDAO dao=new ProductoDAO();
    int id;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Controller</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Controller at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String acceso="";
        String action=request.getParameter("accion");
        if(action.equalsIgnoreCase("listar")){
            System.out.print("Entrando a Listar");
            acceso=listar;            
        }else if(action.equalsIgnoreCase("add")){
            acceso=add;
        }
        else if(action.equalsIgnoreCase("Agregar")){
            String serial=request.getParameter("txtSerial");
            String categoria=request.getParameter("txtCategoria");
            String marca=request.getParameter("txtMarca");
            String refer=request.getParameter("txtRefer");
            int precio=Integer.parseInt(request.getParameter("txtPrecio"));
            
            
            p.setSerialP(serial);
            p.setCategoriaP(categoria);
            p.setMarcaP(marca);
            p.setRefP(refer);
            p.setPrecio(precio);
            
            dao.add(p);
            acceso=listar;
            
        }
        else if(action.equalsIgnoreCase("editar")){
            request.setAttribute("idpro",request.getParameter("id"));
            acceso=edit;
        }
        else if(action.equalsIgnoreCase("Actualizar")){
            id=Integer.parseInt(request.getParameter("txtid"));
            String serial=request.getParameter("txtSerial");
            String categoria=request.getParameter("txtCategoria");
            String marca=request.getParameter("txtMarca");
            String refer=request.getParameter("txtRefer");
            int precio=Integer.parseInt(request.getParameter("txtPrecio"));
            
            p.setId(id);
            p.setSerialP(serial);
            p.setCategoriaP(categoria);
            p.setMarcaP(marca);
            p.setRefP(refer);
            p.setPrecio(precio);
            dao.edit(p);
            acceso=listar;
        }
        else if(action.equalsIgnoreCase("eliminar")){
            id=Integer.parseInt(request.getParameter("id"));
            p.setId(id);
            dao.eliminar(id);
            acceso=listar;
        }
        RequestDispatcher vista=request.getRequestDispatcher(acceso);
        vista.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
