/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


/**
 *
 * @author Camilo Hernandez
 */

public class Producto implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;
    private String serialP;
    private String categoriaP;
    private String marcaP;
    private String refP;
    private int precio;
    
    public Producto() {
    }

    public Producto(Integer id) {
        this.id = id;
    }

    public Producto(Integer id, String serialP, String categoriaP, String marcaP, String refP, int precio) {
        this.id = id;
        this.serialP = serialP;
        this.categoriaP = categoriaP;
        this.marcaP = marcaP;
        this.refP = refP;
        this.precio = precio;
    }

    public Producto(String serialP, String categoriaP, String marcaP, String refP, int precio) {
        this.serialP = serialP;
        this.categoriaP = categoriaP;
        this.marcaP = marcaP;
        this.refP = refP;
        this.precio = precio;
    }

    
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSerialP() {
        return serialP;
    }

    public void setSerialP(String serialP) {
        this.serialP = serialP;
    }

    public String getCategoriaP() {
        return categoriaP;
    }

    public void setCategoriaP(String categoriaP) {
        this.categoriaP = categoriaP;
    }

    public String getMarcaP() {
        return marcaP;
    }

    public void setMarcaP(String marcaP) {
        this.marcaP = marcaP;
    }

    public String getRefP() {
        return refP;
    }

    public void setRefP(String refP) {
        this.refP = refP;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Producto)) {
            return false;
        }
        Producto other = (Producto) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.Producto[ id=" + id + " ]";
    }
    
}
