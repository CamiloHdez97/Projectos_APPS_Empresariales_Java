/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sga.cliente;
import java.util.List;
import javax.naming.*;
import sga.dominio.Persona;
import sga.service.PersonaServiceRemote;

/**
 *
 * @author debian
 */
public class ClientePersonaService {
    public static void main(String[] args) throws NamingException{
        System.out.println("Iniciando llamada al EJB desde el cliente");
        System.out.println("");
        try{
            Context jndi = new InitialContext();
            PersonaServiceRemote personaService = (PersonaServiceRemote)
            jndi.lookup("java:global/sga/PersonaServiceImpl!sga.service.PersonaServiceRemote");
            List<Persona> personas = personaService.listarPersonas();
            
            for(Persona persona: personas){
                System.out.println(persona);
            }
            
            System.out.println("");
            System.out.println("Fin llamada al EJB desde el cliente.");
            
            
        
        } catch (NamingException ex){
            ex.printStackTrace(System.out);
        }
    
    }
    
}
