/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sga.service;

import java.util.ArrayList;
import java.util.List;
import sga.dominio.Persona;

/**
 *
 * @author debian
 */
public class PersonaServiceImp implements PersonaServiceRemote,PersonaService{

    @Override
    public List<Persona> listarPersonas() {
        
        List<Persona> personas = new ArrayList<>();
        personas.add(new Persona(1,"Camilo","Hernandez","camilo@gmail.com","12345678"));
        personas.add(new Persona(2,"Andres","Diaz","andres@gmail.com","987654321"));
        return personas;
           
    }

    @Override
    public Persona encontrarPersonaPorId(Persona persona) {
        return null;
    }

    @Override
    public Persona encontrarPersonaPorEmail(Persona persona) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void registrarPersona(Persona persona) {
       
    }

    @Override
    public void modificarPersona(Persona persona) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void eliminarPersona(Persona persona) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
